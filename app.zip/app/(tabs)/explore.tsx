import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Alert, ActivityIndicator, TouchableOpacity } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { Card, Button as UIButton } from 'react-native-paper';
import { API_URL } from '@/constants/config';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const RegisterScreen = () => {
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phone: '',
    dob: new Date(),
    password: '',
    showDatePicker: false,
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (name, value) => {
    setForm({ ...form, [name]: value });
  };

  const handleDateConfirm = (selectedDate) => {
    setForm({ ...form, dob: selectedDate, showDatePicker: false });
  };

  const handleSignup = async () => {
    setLoading(true);

    const userData = {
      firstName: form.firstName.trim(),
      lastName: form.lastName.trim(),
      username: form.username.trim().toLowerCase(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      dob: form.dob.toISOString(),
      password: form.password,
    };

    try {
      const response = await fetch(`${API_URL}/users/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });

      const data = await response.json();
      setLoading(false);

      if (response.ok) {
        await AsyncStorage.setItem('userId', data.user._id);
        await AsyncStorage.setItem('authToken', data.token);
        Alert.alert('Success', 'User registered successfully!', [
          { text: 'Go to Profile', onPress: () => router.replace('/users') }
        ]);
      } else {
        Alert.alert('Error', data.message || 'Something went wrong');
      }
    } catch (error) {
      setLoading(false);
      Alert.alert('Error', 'Failed to connect to the server');
    }
  };

  return (
    <View style={styles.innerContainer}>
      <Card style={styles.card}>
        <Text style={styles.title}>Register</Text>
        <TextInput placeholder="First Name" value={form.firstName} onChangeText={(text) => handleChange('firstName', text)} style={styles.input} />
        <TextInput placeholder="Last Name" value={form.lastName} onChangeText={(text) => handleChange('lastName', text)} style={styles.input} />
        <TextInput placeholder="Username" value={form.username} onChangeText={(text) => handleChange('username', text)} style={styles.input} />
        <TextInput placeholder="Email" value={form.email} keyboardType="email-address" onChangeText={(text) => handleChange('email', text)} style={styles.input} />
        <TextInput placeholder="Phone" value={form.phone} keyboardType="phone-pad" onChangeText={(text) => handleChange('phone', text)} style={styles.input} />
        <TextInput placeholder="Password" value={form.password} secureTextEntry onChangeText={(text) => handleChange('password', text)} style={styles.input} />

        <TouchableOpacity onPress={() => setForm({ ...form, showDatePicker: true })}>
          <Text style={styles.dateText}>{form.dob.toDateString()}</Text>
        </TouchableOpacity>
        <DateTimePickerModal
          isVisible={form.showDatePicker}
          mode="date"
          onConfirm={handleDateConfirm}
          onCancel={() => setForm({ ...form, showDatePicker: false })}
        />

        <UIButton mode="contained" style={styles.button} onPress={handleSignup}>
          Sign Up
        </UIButton>
      </Card>
    </View>
  );
};

const styles = StyleSheet.create({
  innerContainer: { padding: 20, flex: 1, justifyContent: 'center', backgroundColor: '#fff' },
  card: { padding: 20, borderRadius: 10, backgroundColor: 'white', elevation: 3 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10, textAlign: 'center', color: '#333' },
  input: { marginBottom: 10, borderWidth: 1, padding: 12, borderRadius: 5, borderColor: '#ccc', backgroundColor: '#f9f9f9' },
  dateText: { padding: 10, borderWidth: 1, borderColor: '#ccc', borderRadius: 5, textAlign: 'center', backgroundColor: '#f9f9f9' },
  button: { marginTop: 20, paddingVertical: 10, backgroundColor: '#FF385C' },
});

export default RegisterScreen;
