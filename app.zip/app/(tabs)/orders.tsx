import React from 'react';
import { View, Text } from 'react-native';

export default function OrdersScreen() {
    return (
        <View>
            <Text>Orders Page</Text>
        </View>
    );
}
